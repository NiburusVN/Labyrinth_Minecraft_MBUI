package model;

import java.util.ArrayList;
import java.util.Arrays;

public class Hallway extends TileTemplate {

    public Hallway() {
        super();
    }

    //surcharge du constructeur (niveau 1 des tuiles: on choisi l'orientation)
    public Hallway(Direction orientation) {
        super(orientation);
    }

    @Override
    //Fonction pour vérifier la validité des déplacements
    public ArrayList<Boolean> getEntries() {
        // 1er indice : Ouest, 2ème indice : Nord, 3ème indice: Est, 4ème indice: Sud
        ArrayList<Boolean> entries = new ArrayList<Boolean>();

        switch (this._orientation) {

            case Direction.NORTH:
            case Direction.SOUTH:
                entries.addAll(Arrays.asList(false, true, false, true));

            case Direction.EAST:
            case Direction.WEST:
                entries.addAll(Arrays.asList(true, false, true, false));

        }
        return entries;
    }

    @Override
    public String getType() {
        return "Hallway";
    }
}
